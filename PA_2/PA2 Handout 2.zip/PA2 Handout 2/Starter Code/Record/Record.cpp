//implementation of record class

#include "Record.h"
