#include <iostream>
#include "Stress_ball_test.h"
#include "Jeans_test.h"
using namespace std;
int main() {   
    test_stress_balls();
    test_jeans();
    return 0; 
} 